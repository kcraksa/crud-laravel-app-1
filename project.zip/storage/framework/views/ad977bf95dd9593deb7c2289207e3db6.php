<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Transactions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container mx-auto py-6 sm:px-6 lg:px-8">
      <div class="row mb-4">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                      <h5 class="card-title">Total Balance</h5>
                      <h6 class="card-subtitle mb-2 text-muted">Your current balance</h6>
                      <p class="card-text">Rp <?php echo e($currentBalance); ?></p>
                  </div>
              </div>
          </div>
      </div>
        <div class="row">
            <div class="col-md-12">
                <h2 class="mb-3 font-bold text-xl">Daftar Transaksi</h2>
                <div class="text-end">
                  <a href="/create-transaction" class="btn btn-primary my-4">Create Transaction</a>
                </div>
                <table id="transactionTable" class="table">
                    <thead>
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Tipe Transaksi</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                            <th>Bukti Topup</th>
                            <th>Waktu Transaksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($transaction->transaction_code); ?></td>
                            <td><?php echo e($transaction->type); ?></td>
                            <td><?php echo e($transaction->amount); ?></td>
                            <td><?php echo e($transaction->description); ?></td>
                            <td>
                                <?php if($transaction->proof_url): ?>
                                <a href="<?php echo e(asset('storage/'.$transaction->proof_url)); ?>" target="_blank">Lihat Bukti Topup</a>
                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($transaction->created_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#transactionTable').DataTable();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php /**PATH D:\laragon\www\test-project-20240516\resources\views/transactions/index.blade.php ENDPATH**/ ?>