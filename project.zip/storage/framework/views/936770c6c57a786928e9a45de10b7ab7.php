
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create Transaction')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-2xl mx-auto py-6 sm:px-6 lg:px-8">
      <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
          <div class="p-6 bg-white border-b border-gray-200">
              <form action="<?php echo e(route('transaction.store')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                  <div>
                      <label for="type" class="block font-medium text-sm text-gray-700">Tipe Transaksi</label>
                      <select name="type" id="type" class="form-select mt-1 block w-full" >
                          <option value="topup">Topup</option>
                          <option value="transaction">Transaksi</option>
                      </select>
                  </div>

                  <div class="mt-4">
                      <label for="amount" class="block font-medium text-sm text-gray-700">Jumlah</label>
                      <input type="number" name="amount" id="amount" class="form-input mt-1 block w-full">
                  </div>

                  <div class="mt-4">
                      <label for="description" class="block font-medium text-sm text-gray-700">Keterangan</label>
                      <textarea name="description" id="description" rows="3" class="form-textarea mt-1 block w-full"></textarea>
                  </div>

                  <div class="mt-4" id='uploadField'>
                      <label for="proof" class="block font-medium text-sm text-gray-700">Bukti Topup</label>
                      <input type="file" name="proof" id="proof" class="form-input mt-1 block w-full">
                  </div>

                  <div class="mt-6">
                      <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                          Simpan
                      </button>
                  </div>
              </form>
          </div>
      </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
        var type = document.getElementById('type');
        var uploadField = document.getElementById('uploadField');

        type.addEventListener('change', function() {
            if (type.value === 'topup') {
                uploadField.style.display = 'block';
            } else {
                uploadField.style.display = 'none';
            }
        });
    });
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\test-project-20240516\resources\views/transactions/create.blade.php ENDPATH**/ ?>